export default {
	async credentials () {
		const email = appsmith.URL.queryParams.email;
		const pass_hash = appsmith.URL.queryParams.pass;
		
	}
}