export default {
	userData () {
		return {
			"user" : appsmith.store.user
	}
}
}